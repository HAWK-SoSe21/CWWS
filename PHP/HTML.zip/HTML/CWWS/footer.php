        <div class="footer">
            <div class="navbarfooter">
                <p class="copyright">©HAWK</p>
                <li><a href="#">Kontakt</a></li>
                <li><a href="#">Impressum</a></li>
                <li><a href="#">Datenschutz</a></li>
            </div>
        </div>
        
        <script src="<?= WEBROOT ?><?= UV ?>JAVA/script.js"></script>
        <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
        <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    </body><!-- Autoren: Daniel Weber, Frank Guane Bi -->
</html>