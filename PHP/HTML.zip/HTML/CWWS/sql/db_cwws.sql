-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 15. Jul 2021 um 04:20
-- Server-Version: 10.4.18-MariaDB
-- PHP-Version: 7.4.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `db_cwws`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `aliase`
--

CREATE TABLE `aliase` (
  `Aliase_1` varchar(45) NOT NULL,
  `Articel_Articel_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `articel`
--

CREATE TABLE `articel` (
  `Articel_id` int(11) NOT NULL,
  `Articel_picture` varchar(255) NOT NULL,
  `Articel_expiry` date DEFAULT NULL,
  `Articel_fragile` tinyint(1) DEFAULT NULL,
  `Articel_group_Articel_group_id` int(11) DEFAULT NULL,
  `Usage_statistics_Usage_statistics_id` int(11) DEFAULT NULL,
  `order_order_id` int(11) DEFAULT NULL,
  `Properties_Properties_id` int(11) NOT NULL,
  `Format_Format_id` int(11) NOT NULL,
  `user_User_id` int(11) NOT NULL,
  `aliase` varchar(255) DEFAULT NULL,
  `Substorage_yard_Substorage_mobile_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `articel_group`
--

CREATE TABLE `articel_group` (
  `Articel_group_id` int(11) NOT NULL,
  `Articel_group_picture` varchar(255) DEFAULT NULL,
  `last_modified_last_modified_id` int(11) DEFAULT NULL,
  `Properties_Properties_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `format`
--

CREATE TABLE `format` (
  `Format_id` int(11) NOT NULL,
  `Format_height` varchar(55) NOT NULL,
  `Format_width` varchar(55) NOT NULL,
  `Format_length` varchar(55) NOT NULL,
  `Format_volume` varchar(55) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `last_modified`
--

CREATE TABLE `last_modified` (
  `last_modified_id` int(11) NOT NULL,
  `last_modified_datetime` datetime DEFAULT NULL,
  `last_modified_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `order`
--

CREATE TABLE `order` (
  `order_id` int(11) NOT NULL,
  `order_stackable` tinyint(1) DEFAULT NULL,
  `order_rotateable` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `properties`
--

CREATE TABLE `properties` (
  `Properties_id` int(11) NOT NULL,
  `Properties_name` varchar(45) NOT NULL,
  `Properties_description` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `storage_yard`
--

CREATE TABLE `storage_yard` (
  `Storage_id` int(11) NOT NULL,
  `Storage_picture` varchar(255) NOT NULL,
  `Storage_last_modified` datetime DEFAULT NULL,
  `Usage_statistics_idUsage_statistics` int(11) DEFAULT NULL,
  `Format_Format_id` int(11) NOT NULL,
  `Properties_Properties_id` int(11) NOT NULL,
  `user_User_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `subarticel`
--

CREATE TABLE `subarticel` (
  `Subarticel_id` int(11) NOT NULL,
  `Subarticel_quantity` int(11) DEFAULT NULL,
  `Subarticel_quantity_is_procent` tinyint(1) DEFAULT NULL,
  `Subarticel_binding` tinyint(1) DEFAULT NULL,
  `Subarticel_extracted` tinyint(1) DEFAULT NULL,
  `Subarticel_time_of_storage` date DEFAULT NULL,
  `Articel_Articel_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `substorage_yard`
--

CREATE TABLE `substorage_yard` (
  `Substorage_id` int(11) NOT NULL,
  `Substorage_quantity` int(11) NOT NULL,
  `Substorage_category` varchar(45) NOT NULL,
  `Substorage_picture` varchar(255) DEFAULT NULL,
  `Properties_Properties_id` int(11) DEFAULT NULL,
  `last_modified_last_modified_id` int(11) DEFAULT NULL,
  `Storage_yard_Storage_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `substorage_yard_fixed`
--

CREATE TABLE `substorage_yard_fixed` (
  `Substorage_fixed_id` int(11) NOT NULL,
  `Substorage_fixed_category` varchar(45) NOT NULL,
  `Articel_Articel_id` int(11) DEFAULT NULL,
  `Properties_Properties_id` int(11) DEFAULT NULL,
  `last_modified_last_modified_id` int(11) DEFAULT NULL,
  `Format_Format_id` int(11) NOT NULL,
  `Substorage_yard_Substorage_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `substorage_yard_mobile`
--

CREATE TABLE `substorage_yard_mobile` (
  `Substorage_mobile_id` int(11) NOT NULL,
  `Substorage_mobile_cover` tinyint(1) NOT NULL,
  `Substorage_mobile_category` varchar(45) NOT NULL,
  `Substorage_mobile_binding` tinyint(1) DEFAULT NULL,
  `Substorage_mobile_extracted` tinyint(1) DEFAULT NULL,
  `Substorage_yard_mobile_Substorage_mobile_id` int(11) DEFAULT NULL,
  `Properties_Properties_id` int(11) DEFAULT NULL,
  `order_order_id` int(11) DEFAULT NULL,
  `last_modified_last_modified_id` int(11) DEFAULT NULL,
  `Format_Format_id` int(11) NOT NULL,
  `Articel_Articel_id` int(11) DEFAULT NULL,
  `Substorage_yard_fixed_Substorage_fixed_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `usage_statistics`
--

CREATE TABLE `usage_statistics` (
  `Usage_statistics_id` int(11) NOT NULL,
  `Usage_statistics_number_of_accesses` int(10) UNSIGNED DEFAULT NULL,
  `Usage_statistics_last_modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `User_id` int(11) NOT NULL,
  `User_name` varchar(45) NOT NULL,
  `User_password` varchar(255) NOT NULL,
  `User_email` varchar(45) NOT NULL,
  `User_is_admin` tinyint(1) DEFAULT 0,
  `User_is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`User_id`, `User_name`, `User_password`, `User_email`, `User_is_admin`, `User_is_active`) VALUES
(3, 'admin', '$2y$10$evGMDQrGa05UxGFOFmSbb.jME2YWgCfu0VHwFwbqSON4NSyb/Hcyi', 'admin@php.com', 1, 1);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `aliase`
--
ALTER TABLE `aliase`
  ADD PRIMARY KEY (`Aliase_1`),
  ADD KEY `fk_Aliase_Articel1_idx` (`Articel_Articel_id`);

--
-- Indizes für die Tabelle `articel`
--
ALTER TABLE `articel`
  ADD PRIMARY KEY (`Articel_id`),
  ADD UNIQUE KEY `Articel_id_UNIQUE` (`Articel_id`),
  ADD KEY `fk_Articel_Articel_group1_idx` (`Articel_group_Articel_group_id`),
  ADD KEY `fk_Articel_Properties1_idx` (`Properties_Properties_id`),
  ADD KEY `fk_Articel_Format1_idx` (`Format_Format_id`),
  ADD KEY `fk_Articel_Usage_statistics1_idx` (`Usage_statistics_Usage_statistics_id`),
  ADD KEY `fk_articel_user1_idx` (`user_User_id`),
  ADD KEY `fk_articel_order1_idx` (`order_order_id`);

--
-- Indizes für die Tabelle `articel_group`
--
ALTER TABLE `articel_group`
  ADD PRIMARY KEY (`Articel_group_id`),
  ADD UNIQUE KEY `Articel_id_UNIQUE` (`Articel_group_id`),
  ADD KEY `fk_Articel_group_Properties1_idx` (`Properties_Properties_id`),
  ADD KEY `fk_articel_group_last_modified1_idx` (`last_modified_last_modified_id`);

--
-- Indizes für die Tabelle `format`
--
ALTER TABLE `format`
  ADD PRIMARY KEY (`Format_id`);

--
-- Indizes für die Tabelle `last_modified`
--
ALTER TABLE `last_modified`
  ADD PRIMARY KEY (`last_modified_id`);

--
-- Indizes für die Tabelle `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indizes für die Tabelle `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`Properties_id`),
  ADD UNIQUE KEY `Properties_name_UNIQUE` (`Properties_name`);

--
-- Indizes für die Tabelle `storage_yard`
--
ALTER TABLE `storage_yard`
  ADD PRIMARY KEY (`Storage_id`),
  ADD UNIQUE KEY `Storage_id_UNIQUE` (`Storage_id`),
  ADD KEY `fk_Storage_yard_Format1_idx` (`Format_Format_id`),
  ADD KEY `fk_Storage_yard_Properties1_idx` (`Properties_Properties_id`),
  ADD KEY `fk_Storage_yard_Usage_statistics1_idx` (`Usage_statistics_idUsage_statistics`),
  ADD KEY `fk_storage_yard_user1_idx` (`user_User_id`);

--
-- Indizes für die Tabelle `subarticel`
--
ALTER TABLE `subarticel`
  ADD PRIMARY KEY (`Subarticel_id`),
  ADD UNIQUE KEY `Subarticel_id_UNIQUE` (`Subarticel_id`),
  ADD KEY `fk_Subarticel_Articel1_idx` (`Articel_Articel_id`);

--
-- Indizes für die Tabelle `substorage_yard`
--
ALTER TABLE `substorage_yard`
  ADD PRIMARY KEY (`Substorage_id`),
  ADD KEY `fk_Substorage_yard_Storage_yard1_idx` (`Storage_yard_Storage_id`),
  ADD KEY `fk_Substorage_yard_Properties1_idx` (`Properties_Properties_id`),
  ADD KEY `fk_substorage_yard_last_modified1_idx` (`last_modified_last_modified_id`);

--
-- Indizes für die Tabelle `substorage_yard_fixed`
--
ALTER TABLE `substorage_yard_fixed`
  ADD PRIMARY KEY (`Substorage_fixed_id`),
  ADD KEY `fk_Substorage_yard_fixed_Format1_idx` (`Format_Format_id`),
  ADD KEY `fk_Substorage_yard_fixed_Articel1_idx` (`Articel_Articel_id`),
  ADD KEY `fk_Substorage_yard_fixed_Substorage_yard1_idx` (`Substorage_yard_Substorage_id`),
  ADD KEY `fk_Substorage_yard_fixed_Properties1_idx` (`Properties_Properties_id`),
  ADD KEY `fk_substorage_yard_fixed_last_modified1_idx` (`last_modified_last_modified_id`);

--
-- Indizes für die Tabelle `substorage_yard_mobile`
--
ALTER TABLE `substorage_yard_mobile`
  ADD PRIMARY KEY (`Substorage_mobile_id`),
  ADD UNIQUE KEY `Substorage_mobile_id_UNIQUE` (`Substorage_mobile_id`),
  ADD KEY `fk_Substorage_yard_mobile_Substorage_yard_mobile1_idx` (`Substorage_yard_mobile_Substorage_mobile_id`),
  ADD KEY `fk_Substorage_yard_mobile_Format1_idx` (`Format_Format_id`),
  ADD KEY `fk_Substorage_yard_mobile_Articel1_idx` (`Articel_Articel_id`),
  ADD KEY `fk_Substorage_yard_mobile_Substorage_yard_fixed1_idx` (`Substorage_yard_fixed_Substorage_fixed_id`),
  ADD KEY `fk_Substorage_yard_mobile_Properties1_idx` (`Properties_Properties_id`),
  ADD KEY `fk_substorage_yard_mobile_order1_idx` (`order_order_id`),
  ADD KEY `fk_substorage_yard_mobile_last_modified1_idx` (`last_modified_last_modified_id`);

--
-- Indizes für die Tabelle `usage_statistics`
--
ALTER TABLE `usage_statistics`
  ADD PRIMARY KEY (`Usage_statistics_id`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_id`),
  ADD UNIQUE KEY `User_id_UNIQUE` (`User_id`),
  ADD UNIQUE KEY `User_email_UNIQUE` (`User_email`),
  ADD UNIQUE KEY `User_name_UNIQUE` (`User_name`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `aliase`
--
ALTER TABLE `aliase`
  MODIFY `Articel_Articel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT für Tabelle `articel`
--
ALTER TABLE `articel`
  MODIFY `Articel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT für Tabelle `articel_group`
--
ALTER TABLE `articel_group`
  MODIFY `Articel_group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT für Tabelle `format`
--
ALTER TABLE `format`
  MODIFY `Format_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;

--
-- AUTO_INCREMENT für Tabelle `last_modified`
--
ALTER TABLE `last_modified`
  MODIFY `last_modified_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT für Tabelle `order`
--
ALTER TABLE `order`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT für Tabelle `properties`
--
ALTER TABLE `properties`
  MODIFY `Properties_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT für Tabelle `storage_yard`
--
ALTER TABLE `storage_yard`
  MODIFY `Storage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT für Tabelle `subarticel`
--
ALTER TABLE `subarticel`
  MODIFY `Subarticel_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT für Tabelle `substorage_yard`
--
ALTER TABLE `substorage_yard`
  MODIFY `Substorage_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT für Tabelle `substorage_yard_fixed`
--
ALTER TABLE `substorage_yard_fixed`
  MODIFY `Substorage_fixed_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT für Tabelle `substorage_yard_mobile`
--
ALTER TABLE `substorage_yard_mobile`
  MODIFY `Substorage_mobile_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT für Tabelle `usage_statistics`
--
ALTER TABLE `usage_statistics`
  MODIFY `Usage_statistics_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT für Tabelle `user`
--
ALTER TABLE `user`
  MODIFY `User_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `aliase`
--
ALTER TABLE `aliase`
  ADD CONSTRAINT `fk_Aliase_Articel1` FOREIGN KEY (`Articel_Articel_id`) REFERENCES `articel` (`Articel_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `articel`
--
ALTER TABLE `articel`
  ADD CONSTRAINT `fk_Articel_Articel_group1` FOREIGN KEY (`Articel_group_Articel_group_id`) REFERENCES `articel_group` (`Articel_group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Articel_Format1` FOREIGN KEY (`Format_Format_id`) REFERENCES `format` (`Format_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_Articel_Properties1` FOREIGN KEY (`Properties_Properties_id`) REFERENCES `properties` (`Properties_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Articel_Usage_statistics1` FOREIGN KEY (`Usage_statistics_Usage_statistics_id`) REFERENCES `usage_statistics` (`Usage_statistics_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_articel_order1` FOREIGN KEY (`order_order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_articel_user1` FOREIGN KEY (`user_User_id`) REFERENCES `user` (`User_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `articel_group`
--
ALTER TABLE `articel_group`
  ADD CONSTRAINT `fk_Articel_group_Properties1` FOREIGN KEY (`Properties_Properties_id`) REFERENCES `properties` (`Properties_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_articel_group_last_modified1` FOREIGN KEY (`last_modified_last_modified_id`) REFERENCES `last_modified` (`last_modified_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `storage_yard`
--
ALTER TABLE `storage_yard`
  ADD CONSTRAINT `fk_Storage_yard_Format1` FOREIGN KEY (`Format_Format_id`) REFERENCES `format` (`Format_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Storage_yard_Properties1` FOREIGN KEY (`Properties_Properties_id`) REFERENCES `properties` (`Properties_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Storage_yard_Usage_statistics1` FOREIGN KEY (`Usage_statistics_idUsage_statistics`) REFERENCES `usage_statistics` (`Usage_statistics_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_storage_yard_user1` FOREIGN KEY (`user_User_id`) REFERENCES `user` (`User_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `subarticel`
--
ALTER TABLE `subarticel`
  ADD CONSTRAINT `fk_Subarticel_Articel1` FOREIGN KEY (`Articel_Articel_id`) REFERENCES `articel` (`Articel_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `substorage_yard`
--
ALTER TABLE `substorage_yard`
  ADD CONSTRAINT `fk_Substorage_yard_Properties1` FOREIGN KEY (`Properties_Properties_id`) REFERENCES `properties` (`Properties_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Substorage_yard_Storage_yard1` FOREIGN KEY (`Storage_yard_Storage_id`) REFERENCES `storage_yard` (`Storage_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_substorage_yard_last_modified1` FOREIGN KEY (`last_modified_last_modified_id`) REFERENCES `last_modified` (`last_modified_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `substorage_yard_fixed`
--
ALTER TABLE `substorage_yard_fixed`
  ADD CONSTRAINT `fk_Substorage_yard_fixed_Articel1` FOREIGN KEY (`Articel_Articel_id`) REFERENCES `articel` (`Articel_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Substorage_yard_fixed_Format1` FOREIGN KEY (`Format_Format_id`) REFERENCES `format` (`Format_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Substorage_yard_fixed_Properties1` FOREIGN KEY (`Properties_Properties_id`) REFERENCES `properties` (`Properties_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Substorage_yard_fixed_Substorage_yard1` FOREIGN KEY (`Substorage_yard_Substorage_id`) REFERENCES `substorage_yard` (`Substorage_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_substorage_yard_fixed_last_modified1` FOREIGN KEY (`last_modified_last_modified_id`) REFERENCES `last_modified` (`last_modified_id`) ON DELETE CASCADE;

--
-- Constraints der Tabelle `substorage_yard_mobile`
--
ALTER TABLE `substorage_yard_mobile`
  ADD CONSTRAINT `fk_Substorage_yard_mobile_Articel1` FOREIGN KEY (`Articel_Articel_id`) REFERENCES `articel` (`Articel_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Substorage_yard_mobile_Format1` FOREIGN KEY (`Format_Format_id`) REFERENCES `format` (`Format_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Substorage_yard_mobile_Properties1` FOREIGN KEY (`Properties_Properties_id`) REFERENCES `properties` (`Properties_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Substorage_yard_mobile_Substorage_yard_fixed1` FOREIGN KEY (`Substorage_yard_fixed_Substorage_fixed_id`) REFERENCES `substorage_yard_fixed` (`Substorage_fixed_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_Substorage_yard_mobile_Substorage_yard_mobile1` FOREIGN KEY (`Substorage_yard_mobile_Substorage_mobile_id`) REFERENCES `substorage_yard_mobile` (`Substorage_mobile_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_substorage_yard_mobile_last_modified1` FOREIGN KEY (`last_modified_last_modified_id`) REFERENCES `last_modified` (`last_modified_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_substorage_yard_mobile_order1` FOREIGN KEY (`order_order_id`) REFERENCES `order` (`order_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
