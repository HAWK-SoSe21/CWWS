<?php
//Autoren: PHP-TEAM
include_once '../phpheader.php';
function deleteArticel($id, $object) {
	$sql="DELETE FROM articel WHERE Articel_id='".$id."'";
	setData($sql);
	$sql="DELETE FROM `properties` WHERE Properties_id='".$object->Properties_Properties_id."'";
	setData($sql);
	$sql="DELETE FROM `format` WHERE Format_id='".$object->Format_Format_id."'";
	setData($sql);
	$sql="DELETE FROM `order` WHERE order_id='".$object->order_order_id."'";
	setData($sql);
}
function deleteArticelGroup($id, $object) {
	/*$sql="SELECT * FROM articel WHERE Articel_group_Articel_group_id='".$id."'";
	$articelsToDelete=getDatas($sql);
	foreach($articelsToDelete as $articel) {
		deleteArticel($articel->Articel_id, $articel);
	}*/
	$sql="DELETE FROM articel_group WHERE Articel_group_id='".$id."'";
	setData($sql);
	$sql="DELETE FROM `properties` WHERE Properties_id='".$object->Properties_Properties_id."'";
	setData($sql);
}
function deleteSubstorageMobile($id, $object) {
	$sql="SELECT * FROM articel WHERE Substorage_yard_Substorage_mobile_id='".$id."'";
	$articelToDelete=getDatas($sql);
	foreach($articelToDelete as $articel) {
		deleteArticel($articel->Articel_id, $articel);
	}
	$sql="DELETE FROM substorage_yard_mobile WHERE Substorage_mobile_id='".$id."'";
	setData($sql);
	$sql="DELETE FROM `order` WHERE order_id='".$object->order_order_id."'";
	setData($sql);
	$sql="DELETE FROM `properties` WHERE Properties_id='".$object->Properties_Properties_id."'";
	setData($sql);
	$sql="DELETE FROM `format` WHERE Format_id='".$object->Format_Format_id."'";
	setData($sql);
}
function deleteSubstorageFixed($id, $object) {
	$sql="SELECT * FROM substorage_yard_mobile WHERE Substorage_yard_fixed_Substorage_fixed_id='".$id."'";
	$substoragesMobileToDelete=getDatas($sql);
	foreach($substoragesMobileToDelete as $substorageMobile) {
		deleteSubstorageMobile($substorageMobile->Substorage_mobile_id, $substorageMobile);
	}
	$sql="DELETE FROM substorage_yard_fixed WHERE Substorage_fixed_id='".$id."'";
	setData($sql);
	$sql="DELETE FROM `properties` WHERE Properties_id='".$object->Properties_Properties_id."'";
	setData($sql);
	$sql="DELETE FROM `format` WHERE Format_id='".$object->Format_Format_id."'";
	setData($sql);
}
function deleteSubstorage($id, $object) {
	$sql="SELECT * FROM substorage_yard_fixed WHERE Substorage_yard_Substorage_id='".$id."'";
	$substoragesFixedToDelete=getDatas($sql);
	foreach($substoragesFixedToDelete as $substorageFixed) {
		deleteSubstorageFixed($substorageFixed->Substorage_fixed_id, $substorageFixed);
	}
	$sql="DELETE FROM substorage_yard WHERE Substorage_id='".$id."'";
	setData($sql);
	$sql="DELETE FROM `properties` WHERE Properties_id='".$object->Properties_Properties_id."'";
	setData($sql);
}
function deleteStorage($id, $object) {
	$sql="SELECT * FROM substorage_yard WHERE Storage_yard_Storage_id='".$id."'";
	$substoragesToDelete=getDatas($sql);
	foreach($substoragesToDelete as $substorage) {
		deleteSubstorage($substorage->Substorage_id, $substorage);
	}
	$sql="DELETE FROM storage_yard WHERE Storage_id='".$id."'";
	setData($sql);
	$sql="DELETE FROM `format` WHERE Format_id='".$object->Format_Format_id."'";
	setData($sql);
	$sql="DELETE FROM `properties` WHERE Properties_id='".$object->Properties_Properties_id."'";
	setData($sql);
}
if(isset($_GET['storageid'])) {
	$sql="SELECT * FROM storage_yard WHERE Storage_id='".$_GET['storageid']."'";
	$object=getData($sql);
	deleteStorage($_GET['storageid'], $object);
}
elseif(isset($_GET['substorageid'])) {
	$sql="SELECT * FROM substorage_yard WHERE Substorage_id='".$_GET['substorageid']."'";
	$object=getData($sql);
	deleteSubstorage($_GET['substorageid'], $object);
}
elseif(isset($_GET['substoragefixedid'])) {
	$sql="SELECT * FROM substorage_yard_fixed WHERE Substorage_fixed_id='".$_GET['substoragefixedid']."'";
	$object=getData($sql);
	deleteSubstorageFixed($_GET['substoragefixedid'], $object);
}
elseif(isset($_GET['substoragemobileid'])) {
	$sql="SELECT * FROM substorage_yard_mobile WHERE Substorage_mobile_id='".$_GET['Substorage_mobile_id']."'";
	$object=getData($sql);
	deleteSubstorageMobile($_GET['substoragemobileid'], $object);
}
elseif(isset($_GET['article_group_id'])) {
	$sql="SELECT * FROM articel_group WHERE Articel_group_id='".$_GET['article_group_id']."'";
	$object=getData($sql);
	deleteArticelGroup($_GET['article_group_id'], $object);
}
elseif(isset($_GET['articleid'])) {
	$sql="SELECT * FROM articel WHERE Articel_id='".$_GET['articleid']."'";
	$object=getData($sql);
	deleteArticel($_GET['articleid'], $object);
}
header('location: ../index.php');