<?php
//Autoren: Max Recke, PHP-Team(Ayoub Bassbassi,Elmostafa Hniziz, Hasnae Ba-ouali, Allaeddine Khachouf, Mohamed Chraibi)
try{
    include_once '../phpheader.php';
    if(isset($_POST['submit'])) {
		$Articel_format_height="0";
		$Articel_format_width="0";
		$Articel_format_length="0";
		$Articel_stackable="0";$Articel_rotatable="0";$Articel_fragile="0";
		if(isset($_POST['Articel_format_height']) && $_POST['Articel_format_height']) $Articel_format_height=$_POST['Articel_format_height'];
		if(isset($_POST['Articel_format_width']) && $_POST['Articel_format_width']) $Articel_format_width=$_POST['Articel_format_width'];
		if(isset($_POST['Articel_format_length']) && $_POST['Articel_format_length']) $Articel_format_length=$_POST['Articel_format_length'];
		if(isset($_POST['Articel_stackable']) && $_POST['Articel_stackable']) $Articel_stackable=1;
		if(isset($_POST['Articel_rotatable']) && $_POST['Articel_rotatable']) $Articel_rotatable=1;
		if(isset($_POST['Articel_fragile']) && $_POST['Articel_fragile']) $Articel_fragile=1;

        if(isset($_POST["Articel_picture"])){
            $target_dir = ROOT . "/uploads/articles/";
            $pictureUrl = "/uploads/articles/" . basename($_FILES["Articel_picture"]["name"]);
            $target_file = $target_dir . basename($_FILES["Articel_picture"]["name"]);
            $uploadedFilePath = move_uploaded_file($_FILES["Articel_picture"]["tmp_name"], $target_file);
        }
        else{ $pictureUrl = "/images/article.png"; }
        $authenticatedUserId = $_SESSION["userid"];

        $sql_props = "INSERT INTO `properties`(`Properties_name`, `Properties_description`) VALUES ('".addslashes($_POST['Articel_name'])."', '".addslashes($_POST['Articel_description'])."')";
        $propId = setData($sql_props);

        $sql_format = "INSERT INTO `format` (`Format_height`, `Format_width`, `Format_length`)
			VALUES ('".$Articel_format_height."', '".$Articel_format_width."', '".$Articel_format_length."')";
        $formatId = setData($sql_format);
        $sql_order = "INSERT INTO `order` (`order_stackable`, `order_rotateable`) VALUES ('". $Articel_stackable ."', '". $Articel_rotatable ."')";
		$orderID = setData($sql_order);
        $modified_date = date('Y-m-d H:i:s');
        //$sql_last_mod = "INSERT INTO last_modified (last_modified_datetime, last_modified_user_id) VALUES ('".$modified_date. "', '".$authenticatedUserId. "')";
        //$last_mod_id = setData($sql_last_mod);
        $sql_usage = "INSERT INTO `usage_statistics`(Usage_statistics_number_of_accesses, Usage_statistics_last_modified) VALUES ('".'0'."','".$modified_date."');";
        $usageId = setData($sql_usage);
		$addInsertValue="";
		$addInsertColumn=", `Articel_group_Articel_group_id`, `Articel_expiry`, `aliase`";
		if(isset($_POST["Articel_group_Articel_group_id"]) && $_POST["Articel_group_Articel_group_id"]) $addInsertValue.=", '".$_POST["Articel_group_Articel_group_id"]."'";
		else $addInsertValue.=", NULL";
		if(isset($_POST["Articel_expiry"]) && $_POST["Articel_expiry"]) $addInsertValue.=", '".$_POST["Articel_expiry"]."'";
		else $addInsertValue.=", NULL";
		if(isset($_POST["Articel_alias"]) && $_POST["Articel_alias"]) {
			$addInsertValue.=", '".addslashes($_POST["Articel_alias"])."'";
			$sql = "SELECT count(Articel_id) countExistingAliases FROM articel WHERE aliase LIKE '".addslashes($_POST["Articel_alias"])."'";
			$aliaseExists = getData($sql);
			if($aliaseExists->countExistingAliases>0) {
				$_SESSION["status"]="Alias already exists";
				header('location: ../index.php?error=1');
				exit();
			}
		}
		else $addInsertValue.=", NULL";
		$sql = "INSERT INTO `articel`
			(`Articel_picture`, `Articel_fragile`, `Properties_Properties_id`,  `Format_Format_id`, `User_User_id`, `order_order_id`, `Usage_statistics_Usage_statistics_id`$addInsertColumn)
			VALUES ('".$pictureUrl."', '". $Articel_fragile."', '". $propId."', '" . $formatId . "', '".$authenticatedUserId. "', '".$orderID. "', '".$usageId. "'$addInsertValue)";
        $status = setData($sql);
        if($status){
            $article= getarticlebyid($status);
            if(isset($_POST["Articel_alias"])){
                $sql_aliase = "INSERT INTO `aliase` (`Aliase_1`,`Articel_Articel_id`) VALUES ('". $_POST['Articel_alias'] ."','". $article->Articel_id ."')";
                $aliasid = setData($sql_aliase);
            }
            $sql = "INSERT INTO `subarticel`(`Subarticel_quantity`, `Articel_Articel_id`) VALUES ('0', '".$status. "')";
            $subarticle_id = setData($sql);
            if(!$subarticle_id){
                $_SESSION["status"]="Artikel {$article->Articel_name} wurde angelegt aber Subartikel anlegen fehlgeschlagen";
                header('location: ../index.php?error=0');
                exit();
            }
            $_SESSION["status"]="Artikel {$article->Articel_name} wurde angelegt";
            header('location: ../index.php?error=0');
        }
        else{
            $_SESSION["status"]="Hups! Da ist etwas schief gelaufen... {$e->getMessage()}";
            header('location: ../index.php?error=1');
        }
    }
    elseif(isset($_POST['clear'])){
        $_SESSION["status"]="Funktion noch nicht implementiert";
        $Articel_id=$_POST["Articel_Articel_id"];
		$sql = "DELETE FROM articel WHERE Articel_id = {$Articel_id}";
	    $status = updateData($sql);
        header('location: ../index.php?error=1');
        exit();
    }
}
catch(Exception $e) {
    $_SESSION["status"]="Hups! Da ist etwas schief gelaufen... {$e->getMessage()}";
    header('location: ../index.php?error=1');
}
