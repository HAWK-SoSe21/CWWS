<?php include_once '../header.php'; ?>

<div class="main">
    <div class="mainbox">
        <h3>Funktionsbeschreibung</h3>
        <p>
            Hier sollen in der Entwicklungsphase Funktionsbeschreibungen 
            für Tester und Kunde sein. Ebenfalls sind Bemerkungen zu bestimmten Funktionen gedacht.
        </p>
    </div>
</div>

<?php include_once '../footer.php'; ?>