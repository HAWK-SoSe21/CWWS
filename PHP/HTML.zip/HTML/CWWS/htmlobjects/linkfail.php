<!-- Autoren: Max Recke -->
<?php
    $_SESSION["status"]="Rücksetzlink ungültig";
?>
<?php include_once ROOT."/PHP/status.inc.php"?>
<img src="../images/hackerman.jpg" alt="Hallo Hackerman">
