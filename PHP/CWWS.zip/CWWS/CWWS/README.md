# CWWS
Projekt CWWS (Chaotisches Warenwirtschaftssystem) Softwareengineering SoSe21

## Wiki
[Hauptseite](https://github.com/HAWK-SoSe21/CWWS/wiki/Home)\
[Teamstruktur](https://github.com/HAWK-SoSe21/CWWS/wiki/Teamstruktur)
