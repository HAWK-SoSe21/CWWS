        <div class="footer">
            <div class="navbarfooter">
                <p class="copyright">©HAWK</p>
                <li><a href="#">Kontakt</a></li>
                <li><a href="#">Impressum</a></li>
                <li><a href="#">Datenschutz</a></li>
            </div>
        </div>
        
        <script src="<?= WEBROOT ?><?= UV ?>JAVA/script.js"></script>
    </body>
</html>