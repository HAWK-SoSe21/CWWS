<?php include_once 'header.php';?>

    <div class="main">
        <div class="maingrid">
            <div class="sidebar">
                <div class="sidebar-button-wrapper">
                    <a class="sidebar-button" href="/storage.php/lagerplatzanlegen">Lagerplatz anlegen</a>
                </div>
                <div class="sidebar-button-wrapper">
                    <a class="sidebar-button" href="#">Lagerplatz bearbeiten</a>
                </div>
                <div class="sidebar-button-wrapper">
                    <a class="sidebar-button" href="#">Artikel anlegen</a>
                </div>
                <div class="sidebar-button-wrapper">
                    <a class="sidebar-button" href="#">Artikel bearbeiten</a>
                </div>
            </div>
            <div class="contentgrid">
                <div class="mainbox">
                        <section class="lagerplatz-anlegen-form">
                            <h2>Articel  anlegen</h2>
                            <form action="includes/artikelanlegen.inc.php" method="post">
                                <input type="text" name="Articel_name" placeholder="Articel_name...">
                                <input type="text" name="Articel_format_height" placeholder="Articel_format_height...">
                                <input type="text" name="Articel_format_width" placeholder="Articel_format_width...">
                                <input type="text" name="Articel_format_length" placeholder="Articel_format_length...">
                                <input type="text" name="Articel_picture" placeholder="Articel_picture...">
                                <input type="text" name="Articel_description" placeholder="Articel_description...">
                                <input type="text" name="Articel_alias" placeholder="Articel_alias...">
                                <input type="text" name="Articel_expiry" placeholder="Articel_expiry...">
                                <button type="submit"name="submit">Articel anlegen</button>
                            </form>
                            <?php
                            if(isset($_GET["error"])){
                                if($_GET["error"]=="emptyinput"){
                                    echo"<p>Fill in all fields!</p>";
                                }
                                else if($_GET["error"]=="stmtfailed"){
                                    echo"<p>Something went wrong, try again!</p>";
                                }
                                else if($_GET["error"]=="none"){
                                    echo"<p>Artikel wurde angelegt.</p>";
                                }
                            }
                            ?>
                        </section>
                    </div>
            </div>

        </div>
    </div>

<?php include_once 'footer.php';?>
