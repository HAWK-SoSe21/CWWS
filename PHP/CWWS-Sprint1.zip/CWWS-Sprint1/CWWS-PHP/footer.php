        <div class="footer">
            <div class="navbarfooter">
                <p class="copyright">©HAWK</p>
                <li><a href="contact.php">Kontakt</a></li>
                <li><a href="impressum.php">Impressum</a></li>
                <li><a href="datalaw.php">Datenschutz</a></li>
            </div>
        </div>

        <script src="<?= WEBROOT ?>/script.js"></script>
    </body>
</html>
