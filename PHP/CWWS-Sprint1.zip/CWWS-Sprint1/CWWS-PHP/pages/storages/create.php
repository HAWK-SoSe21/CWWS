<?php

include_once '../../header.php';

$message = '';

if(isset($_POST['submit'])) {
  $target_dir = ROOT . "/uploads/storages/";
  $pictureUrl = "/uploads/storages/" . basename($_FILES["Storage_picture"]["name"]);
  $target_file = $target_dir . basename($_FILES["Storage_picture"]["name"]);
  $uploadedFilePath = move_uploaded_file($_FILES["Storage_picture"]["tmp_name"], $target_file);
  $authenticatedUserId = $_SESSION["userid"];
  $sql = "INSERT INTO `storage_yard`(`Storage_name`, `Storage_description`, `Storage_category`, `Storage_picture`, `Storage_format_heigth`, `Storage_format_width`, `Storage_format_length`, `Storage_furniture`, `User_User_id`) VALUES ('". $_POST['Storage_name'] ."', '". $_POST['Storage_description'] ."', '". $_POST['Storage_category'] ."', '". $pictureUrl ."', '". $_POST['Storage_format_heigth'] ."', '". $_POST['Storage_format_width'] ."', '". $_POST['Storage_format_length'] ."', '". $_POST['Storage_furniture'] ."', $authenticatedUserId)";

  $status = setData($sql);

  if($status) {
    header('location: index.php');
  }
}

?>
  <div class="main">
      <div class="maingrid">
          <div class="sidebar"></div>

          <div class="content">
              <div class="mainbox">
                <select id="dropdown1" onchange="window.location = this.value">
                  <option selected value="<?= WEBROOT . '/pages/storages/create.php' ?>">Lagerplatz anlegen</option>
                  <option value="<?= WEBROOT . '/pages/articles/create.php' ?>">Artikel anlegen</option>
                </select>
                <br>
                <br>
                <h3>Create new Storage</h3>
                <form class="" method="post" enctype="multipart/form-data">
                  <div class="">
                    <label for="name">Storage_name</label>
                    <input type="text" name="Storage_name">
                  </div>
                  <div class="">
                    <label for="name">Storage_description</label>
                    <input type="text" name="Storage_description">
                  </div>
                  <div class="">
                    <label for="name">Storage_category</label>
                    <input type="text" name="Storage_category">
                  </div>
                  <div class="">
                    <label for="name">Storage_picture</label>
                    <input type="file" name="Storage_picture">
                  </div>
                  <div class="">
                    <label for="name">Storage_format_heigth</label>
                    <input type="number" name="Storage_format_heigth">
                  </div>
                  <div class="">
                    <label for="name">Storage_format_width</label>
                    <input type="number" name="Storage_format_width">
                  </div>
                  <div class="">
                    <label for="name">Storage_format_length</label>
                    <input type="number" name="Storage_format_length">
                  </div>
                  <div class="">
                    <label for="name">Storage_furniture</label>
                    <input type="text" name="Storage_furniture">
                  </div>
                  <button type="submit" name="submit">submit</button>
                </form>
              </div>
          </div>
        </div>
  </div>
<?php include_once '../../footer.php';?>
