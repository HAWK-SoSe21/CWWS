<?php

include_once '../../header.php';

$message = '';
$authenticatedUserId = $_SESSION["userid"];

$storage = null;

if(isset($_GET['id'])) {
  $sql = "SELECT * FROM storage_yard WHERE Storage_id = '" . $_GET['id'] . "'";
  $storage = getData($sql);
}

if(!$storage) {
  header('location: index.php');
}

if(isset($_POST['submit'])) {
  if($_FILES["Storage_picture"]['name']) {
    $target_dir = ROOT . "/uploads/storages/";
    $pictureUrl = "/uploads/storages/" . basename($_FILES["Storage_picture"]["name"]);
    $target_file = $target_dir . basename($_FILES["Storage_picture"]["name"]);
    $uploadedFilePath = move_uploaded_file($_FILES["Storage_picture"]["tmp_name"], $target_file);
    $sql = "UPDATE `storage_yard` SET `Storage_name` = '". $_POST['Storage_name'] ."', `Storage_description` = '". $_POST['Storage_description'] ."', `Storage_category` = '". $_POST['Storage_category'] ."', `Storage_format_heigth` = '". $_POST['Storage_format_heigth'] ."', `Storage_picture` = '". $pictureUrl ."', `Storage_format_width` = '". $_POST['Storage_format_width'] ."', `Storage_format_length` = '". $_POST['Storage_format_length'] ."', `Storage_furniture` = '". $_POST['Storage_furniture'] ."' WHERE `Storage_id` = '". $_POST['Storage_id'] ."'";
  } else {
      $sql = "UPDATE `storage_yard` SET `Storage_name` = '". $_POST['Storage_name'] ."', `Storage_description` = '". $_POST['Storage_description'] ."', `Storage_category` = '". $_POST['Storage_category'] ."', `Storage_format_heigth` = '". $_POST['Storage_format_heigth'] ."', `Storage_format_width` = '". $_POST['Storage_format_width'] ."', `Storage_format_length` = '". $_POST['Storage_format_length'] ."', `Storage_furniture` = '". $_POST['Storage_furniture'] ."' WHERE `Storage_id` = '". $_POST['Storage_id'] ."'";
  }

  $status = setData($sql);

  if($status) {
    header('location: index.php');
  }
}

?>

  <div class="main">
      <div class="maingrid">
          <div class="sidebar"></div>

          <div class="content">
              <div class="mainbox">
                <select id="dropdown1" onchange="window.location = this.value">
                  <option selected>===</option>
                  <option value="<?= WEBROOT . '/pages/storages/create.php' ?>">Lagerplatz anlegen</option>
                  <option value="<?= WEBROOT . '/pages/articles/create.php' ?>">Artikel anlegen</option>
                </select>
                <br>
                <br>
                <h3>Edit storage</h3>
                <?php if ($message): ?>
                  <p><?= $message ?></p>
                <?php endif; ?>
                <form class="" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="Storage_id" value="<?= $storage->Storage_id ?>">
                  <div class="">
                    <label for="name">Storage_name</label>
                    <input type="text" name="Storage_name" value="<?= $storage->Storage_name ?>">
                  </div>
                  <div class="">
                    <label for="name">Storage_description</label>
                    <input type="text" name="Storage_description" value="<?= $storage->Storage_description ?>">
                  </div>
                  <div class="">
                    <label for="name">Storage_category</label>
                    <input type="text" name="Storage_category" value="<?= $storage->Storage_category ?>">
                  </div>
                  <div class="">
                    <label for="name">Storage_picture</label>
                    <img style="height: 100px; width: 200px" src="<?= WEBROOT . $storage->Storage_picture ?>" alt="">
                    <input type="file" name="Storage_picture" value="<?= $storage->Storage_picture ?>">
                  </div>
                  <div class="">
                    <label for="name">Storage_format_heigth</label>
                    <input type="number" name="Storage_format_heigth" value="<?= $storage->Storage_format_heigth ?>">
                  </div>
                  <div class="">
                    <label for="name">Storage_format_width</label>
                    <input type="number" name="Storage_format_width" value="<?= $storage->Storage_format_width ?>">
                  </div>
                  <div class="">
                    <label for="name">Storage_format_length</label>
                    <input type="number" name="Storage_format_length" value="<?= $storage->Storage_format_length ?>">
                  </div>
                  <div class="">
                    <label for="name">Storage_furniture</label>
                    <input type="text" name="Storage_furniture" value="<?= $storage->Storage_furniture ?>">
                  </div>
                  <button type="submit" name="submit">submit</button>
                </form>
              </div>
          </div>
        </div>
  </div>
<?php include_once '../../footer.php';?>
