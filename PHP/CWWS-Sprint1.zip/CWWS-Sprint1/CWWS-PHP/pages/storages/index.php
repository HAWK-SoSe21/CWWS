<?php

include_once '../../header.php';

$authenticatedUserId = $_SESSION["userid"];
$sql = "SELECT * FROM storage_yard";

$Storages = getDatas($sql);
?>

  <div class="main">
      <div class="maingrid">
          <div class="sidebar"></div>

          <div class="content">
              <div class="mainbox">
                <select id="dropdown1" onchange="window.location = this.value">
                  <option selected>===</option>
                  <option value="<?= WEBROOT . '/pages/storages/create.php' ?>">Lagerplatz anlegen</option>
                  <option value="<?= WEBROOT . '/pages/articles/create.php' ?>">Artikel anlegen</option>
                </select>
                <br>
                <br>
                <h3>Storage</h3>
                <table border="2">
                  <tr>
                      <th>Fotos</th>
                      <th>Lageplatz id</th>
                      <th>Lageplatz Name</th>
                      <th>Lageplatz Description</th>
                      <th>Lagerplatzkategorie</th>
                      <th>Lageplatz height</th>
                      <th>Lageplatz width</th>
                      <th>Lageplatz length</th>
                      <th>Lageplatz furniture</th>
                      <th>Actions</th>
                  </tr>
                  <?php foreach ($Storages as $Storag): ?>
                    <tr>
                        <td>
                          <img style="height: 70px; width: 70px" src="<?= WEBROOT . $Storag->Storage_picture ?>" alt="">
                        </td>
                        <td><?= $Storag->Storage_id ?></td>
                        <td><?= $Storag->Storage_name ?></td>
                        <td><?= $Storag->Storage_description ?></td>
                        <td><?= $Storag->Storage_category ?></td>
                        <td><?= $Storag->Storage_format_heigth ?></td>
                        <td><?= $Storag->Storage_format_width ?></td>
                        <td><?= $Storag->Storage_format_length ?></td>
                        <td><?= $Storag->Storage_furniture ?></td>
                        <td>
                          <a href="<?= WEBROOT . '/pages/storages/edit.php?id=' . $Storag->Storage_id  ?>">Modifizieren</a>
                        </td>
                    </tr>
                  <?php endforeach; ?>
                </table>
              </div>
          </div>
        </div>
  </div>
<?php include_once '../../footer.php';?>
