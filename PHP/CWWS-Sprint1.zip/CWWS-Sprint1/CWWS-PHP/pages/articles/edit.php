<?php

include_once '../../header.php';

$message = '';
$authenticatedUserId = $_SESSION["userid"];

$article = null;

if(isset($_GET['id'])) {
  $sql = "SELECT * FROM articel WHERE Articel_id = '" . $_GET['id'] . "'";
  $article = getData($sql);
}

if(!$article) {
  header('location: index.php');
}

if(isset($_POST['submit'])) {
  if($_FILES["Articel_picture"]['name']) {
    $target_dir = ROOT . "/uploads/articles/";
    $pictureUrl = "/uploads/articles/" . basename($_FILES["Articel_picture"]["name"]);
    $target_file = $target_dir . basename($_FILES["Articel_picture"]["name"]);
    $uploadedFilePath = move_uploaded_file($_FILES["Articel_picture"]["tmp_name"], $target_file);
    $sql = "UPDATE `articel` SET `Articel_name` = '". $_POST['Articel_name'] ."', `Articel_format_height` = '". $_POST['Articel_format_height'] ."', `Articel_format_width` = '". $_POST['Articel_format_width'] ."', `Articel_format_length` = '". $_POST['Articel_format_length'] ."', `Articel_picture` = '". $pictureUrl ."', `Articel_description` = '". $_POST['Articel_description'] ."', `Articel_alias` = '". $_POST['Articel_alias'] ."', `Articel_expiry` = '". $_POST['Articel_expiry'] ."' WHERE `Articel_id` = '". $_POST['Articel_id'] ."'";
  } else {
      $sql = "UPDATE `articel` SET `Articel_name` = '". $_POST['Articel_name'] ."', `Articel_format_height` = '". $_POST['Articel_format_height'] ."', `Articel_format_width` = '". $_POST['Articel_format_width'] ."', `Articel_format_length` = '". $_POST['Articel_format_length'] ."', `Articel_description` = '". $_POST['Articel_description'] ."', `Articel_alias` = '". $_POST['Articel_alias'] ."', `Articel_expiry` = '". $_POST['Articel_expiry'] ."' WHERE `Articel_id` = '". $_POST['Articel_id'] ."'";
  }

  $status = setData($sql);

  if($status) {
    header('location: index.php');
  }
}

?>

  <div class="main">
      <div class="maingrid">
          <div class="sidebar"></div>

          <div class="content">
              <div class="mainbox">
                <select id="dropdown1" onchange="window.location = this.value">
                  <option selected>===</option>
                  <option value="<?= WEBROOT . '/pages/storages/create.php' ?>">Lagerplatz anlegen</option>
                  <option value="<?= WEBROOT . '/pages/articles/create.php' ?>">Artikel anlegen</option>
                </select>
                <br>
                <br>
                <h3>Edit an article</h3>
                <?php if ($message): ?>
                  <p><?= $message ?></p>
                <?php endif; ?>
                <form class="" method="post" enctype="multipart/form-data">
                  <input type="hidden" name="Articel_id" value="<?= $article->Articel_id ?>">
                  <div class="">
                    <label for="name">Articel_name</label>
                    <input type="text" name="Articel_name" value="<?= $article->Articel_name ?>">
                  </div>
                  <div class="">
                    <label for="name">Articel_format_height</label>
                    <input type="number" name="Articel_format_height" value="<?= $article->Articel_format_height ?>">
                  </div>
                  <div class="">
                    <label for="name">Articel_format_width</label>
                    <input type="number" name="Articel_format_width" value="<?= $article->Articel_format_width ?>">
                  </div>
                  <div class="">
                    <label for="name">Articel_format_length</label>
                    <input type="number" name="Articel_format_length" value="<?= $article->Articel_format_length ?>">
                  </div>
                  <div class="">
                    <label for="name">Articel_picture</label>
                    <img style="height: 100px; width: 200px" src="<?= WEBROOT . $article->Articel_picture ?>" alt="">
                    <input type="file" name="Articel_picture">
                  </div>
                  <div class="">
                    <label for="name">Articel_description</label>
                    <input type="text" name="Articel_description" value="<?= $article->Articel_description ?>">
                  </div>
                  <div class="">
                    <label for="name">Articel_alias</label>
                    <input type="text" name="Articel_alias" value="<?= $article->Articel_alias ?>">
                  </div>
                  <div class="">
                    <label for="name">Articel_expiry</label>
                    <input type="date" name="Articel_expiry" value="<?= $article->Articel_expiry ?>">
                  </div>
                  <button type="submit" name="submit">submit</button>
                </form>
              </div>
          </div>
        </div>
  </div>
<?php include_once '../../footer.php';?>
