<?php

include_once '../../header.php';

$authenticatedUserId = $_SESSION["userid"];
$sql = "SELECT * FROM articel";

$articles = getDatas($sql);
?>

  <div class="main">
      <div class="maingrid">
          <div class="sidebar"></div>

          <div class="content">
              <div class="mainbox">
                <select id="dropdown1" onchange="window.location = this.value">
                  <option selected>===</option>
                  <option value="<?= WEBROOT . '/pages/storages/create.php' ?>">Lagerplatz anlegen</option>
                  <option value="<?= WEBROOT . '/pages/articles/create.php' ?>">Artikel anlegen</option>
                </select>
                <br>
                <br>
                <h3>Articles</h3>
                <table border="2">
                  <tr>
                      <th>Fotos</th>
                      <th>Articel Id</th>
                      <th>Articel Name</th>
                      <th>Articel height</th>
                      <th>Articel with</th>
                      <th>Articel lenght</th>
                      <th>Articel_description</th>
                      <th>Articel_alias</th>
                      <th>Articel_expiry</th>
                      <th>Actions</th>
                  </tr>
                  <?php foreach ($articles as $article): ?>
                    <tr>
                        <td>
                          <img style="height: 70px; width: 70px" src="<?= WEBROOT . $article->Articel_picture ?>" alt="">
                        </td>
                        <td><?= $article->Articel_id ?></td>
                        <td><?= $article->Articel_name ?></td>
                        <td><?= $article->Articel_format_height ?></td>
                        <td><?= $article->Articel_format_width ?></td>
                        <td><?= $article->Articel_format_length ?></td>
                        <td><?= $article->Articel_description ?></td>
                        <td><?= $article->Articel_alias ?></td>
                        <td><?= $article->Articel_expiry ?></td>
                        <td>
                            <a href="<?= WEBROOT . '/pages/articles/edit.php?id=' . $article->Articel_id  ?>">Modifizieren</a>
                        </td>
                    </tr>
                  <?php endforeach; ?>
                </table>
              </div>
          </div>
        </div>
  </div>
<?php include_once '../../footer.php';?>
