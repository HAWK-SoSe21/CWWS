<?php

include_once '../../header.php';

$message = '';

if(isset($_POST['submit'])) {
  $target_dir = ROOT . "/uploads/articles/";
  $pictureUrl = "/uploads/articles/" . basename($_FILES["Articel_picture"]["name"]);
  $target_file = $target_dir . basename($_FILES["Articel_picture"]["name"]);
  $uploadedFilePath = move_uploaded_file($_FILES["Articel_picture"]["tmp_name"], $target_file);
  $authenticatedUserId = $_SESSION["userid"];
  $sql = "INSERT INTO `articel`(`Articel_name`, `Articel_format_height`, `Articel_format_width`, `Articel_format_length`, `Articel_picture`, `Articel_description`, `Articel_alias`, `Articel_expiry`, `User_User_id`) VALUES ('". $_POST['Articel_name'] ."', '". $_POST['Articel_format_height'] ."', '". $_POST['Articel_format_width'] ."', '". $_POST['Articel_format_length'] ."', '". $pictureUrl ."', '". $_POST['Articel_description'] ."', '". $_POST['Articel_alias'] ."', '". $_POST['Articel_expiry'] ."', $authenticatedUserId)";

  $status = setData($sql);

  if($status) {
    header('location: index.php');
  }
}

?>

  <div class="main">
      <div class="maingrid">
          <div class="sidebar"></div>

          <div class="content">
              <div class="mainbox">
                <select id="dropdown1" onchange="window.location = this.value">
                  <option value="<?= WEBROOT . '/pages/storages/create.php' ?>">Lagerplatz anlegen</option>
                  <option selected value="<?= WEBROOT . '/pages/articles/create.php' ?>">Artikel anlegen</option>
                </select>
                <br>
                <br>
                <h3>Create new article</h3>
                <?php if ($message): ?>
                  <p><?= $message ?></p>
                <?php endif; ?>
                <form class="" method="post" enctype="multipart/form-data">
                  <div class="">
                    <label for="name">Articel_id</label>
                    <input type="text" name="Articel_id">
                  </div>
                  <div class="">
                    <label for="name">Articel_name</label>
                    <input type="text" name="Articel_name">
                  </div>
                  <div class="">
                    <label for="name">Articel_format_height</label>
                    <input type="text" name="Articel_format_height">
                  </div>
                  <div class="">
                    <label for="name">Articel_format_width</label>
                    <input type="text" name="Articel_format_width">
                  </div>
                  <div class="">
                    <label for="name">Articel_format_length</label>
                    <input type="text" name="Articel_format_length">
                  </div>
                  <div class="">
                    <label for="name">Articel_picture</label>
                    <input type="file" name="Articel_picture">
                  </div>
                  <div class="">
                    <label for="name">Articel_description</label>
                    <input type="text" name="Articel_description">
                  </div>
                  <div class="">
                    <label for="name">Articel_alias</label>
                    <input type="text" name="Articel_alias">
                  </div>
                  <div class="">
                    <label for="name">Articel_expiry</label>
                    <input type="text" name="Articel_expiry">
                  </div>
                  <button type="submit" name="submit">submit</button>
                </form>
              </div>
          </div>
        </div>
  </div>
<?php include_once '../../footer.php';?>
