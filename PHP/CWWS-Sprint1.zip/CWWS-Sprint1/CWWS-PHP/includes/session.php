<?php
    $GLOBALS["user"] = null;
    session_start();
    $GLOBALS["user"] = $_SESSION["userid"];

?>