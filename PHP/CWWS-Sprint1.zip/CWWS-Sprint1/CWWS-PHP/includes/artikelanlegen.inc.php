<?php
    if (isset($_POST["submit"])){
        $Articel_name = $_POST["Articel_name"];
        $Articel_format_height = $_POST["Articel_format_height"];
        $Articel_format_width = $_POST["Articel_format_width"];
        $Articel_format_length = $_POST["Articel_format_length"];
        $Articel_picture = $_POST["Articel_picture"];
        $Articel_description = $_POST["Articel_description"];
        $Articel_alias = $_POST["Articel_alias"];
        $Articel_expiry = $_POST["Articel_expiry"];
        #$Bild = file_get_contents($_FILES['Bild']['tmp_name']);

        require_once 'dbh.inc.php';
        require_once 'functions.inc.php';
        include 'session.php';
        // $myfile = fopen("../newfile.txt", "w") or die("Unable to open file!");
        // $txt = $Name." ".$Kategorie." ".$Beschreibung." ".$Laenge." ".$Hoehe." ". $Breite."\n";
        // fwrite($myfile, $txt);
        // $txt = "Failed"."\n";
       // fwrite($myfile, $txt);
        if (emptyInputArtikelplatzanlegen($Articel_name,$Articel_format_height,$Articel_format_width,$Articel_format_length,$Articel_picture,$Articel_description,$Articel_alias, $Articel_expiry)!==false){
            header("location ../storage.php?error=emptyinput");
            exit();
        }


        Artikelplatzanlegen($conn,$Articel_name,$Articel_format_height,$Articel_format_width,$Articel_format_length,$Articel_picture,$Articel_description,$Articel_alias, $Articel_expiry,userId());

    }
    else{
        header("location: ../storage.php");
    }
?>
