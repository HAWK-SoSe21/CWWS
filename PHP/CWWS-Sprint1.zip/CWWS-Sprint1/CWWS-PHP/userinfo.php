<?php
    session_start();
    if(!isset($_SESSION["username"])){
        echo("nicht angemeldet");
        }
    else{
        echo($_SESSION["username"]);
        ?><a href="logout.php"> Abmelden</a><?php
    }
?>