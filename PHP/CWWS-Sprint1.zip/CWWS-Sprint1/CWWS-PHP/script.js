//active navigation bar
const currentLocation = location.href;
const menuItem= document.querySelectorAll('a');
const menuLength = menuItem.length
for(let i=0;i<menuLength;i++){
    if(menuItem[i].href ===currentLocation){
        menuItem[i].parentNode.className ="active"
    }
}

$(document).ready(function () {
    $('.group').hide();
    $('#option1').show();
    $('#dropdown1').change(function () {
      $('.group').hide();
      $('#'+$(this).val()).show();
    })
  });

 
  
//