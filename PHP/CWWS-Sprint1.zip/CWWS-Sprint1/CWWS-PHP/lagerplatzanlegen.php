<?php include_once 'header.php';?>
 
    <div class="main">
        <div class="maingrid">
            <div class="sidebar">
                <div class="sidebar-button-wrapper">
                    <a class="sidebar-button" href="/storage.php/lagerplatzanlegen">Lagerplatz anlegen</a>
                </div>
                <div class="sidebar-button-wrapper">
                    <a class="sidebar-button" href="#">Lagerplatz bearbeiten</a>
                </div>
                <div class="sidebar-button-wrapper">
                    <a class="sidebar-button" href="#">Artikel anlegen</a>
                </div>
                <div class="sidebar-button-wrapper">
                    <a class="sidebar-button" href="#">Artikel bearbeiten</a>
                </div>
            </div>
            <div class="contentgrid">
                <div class="mainbox">
                        <section class="lagerplatz-anlegen-form">
                            <h2>Lagerplatz anlegen</h2>
                            <form action="includes/lagerplatzanlegen.inc.php" method="post">
                                <input type="text" name="Name" placeholder="Name...">
                                <input type="text" name="Kategorie" placeholder="Kategorie...">
                                <input type="text" name="Beschreibung" placeholder="Beschreibung...">
                                <input type="text" name="Laenge" placeholder="Länge...">
                                <input type="text" name="Hoehe" placeholder="Höhe...">
                                <input type="text" name="Breite" placeholder="Breite...">
                                <input type="text" name="Bild" placeholder="Bild(optional)...">
                                <button type="submit"name="submit">Lagerplatz anlegen</button>
                            </form>
                            <?php
                            if(isset($_GET["error"])){
                                if($_GET["error"]=="emptyinput"){
                                    echo"<p>Fill in all fields!</p>";
                                }
                                else if($_GET["error"]=="stmtfailed"){
                                    echo"<p>Something went wrong, try again!</p>";
                                }
                                else if($_GET["error"]=="none"){
                                    echo"<p>Artikel wurde angelegt.</p>";
                                }
                            }
                            ?>
                        </section>
                    </div>
            </div>
            
        </div>
    </div>

<?php include_once 'footer.php';?>