<?php include_once 'header.php';?>

            <div class="main">
                <div class="maingrid">
                    <aside class="sidebar">
                        <ul>
                            <li><span>Funktionen</span></li>
                            <li><a href="#">Lagerplatz anlegen</a></li>
                            <li><a href="#">Lagerplatz bearbeiten</a></li>
                            <li><a href="#">Artikel anlegen</a></li>
                            <li><a href="#">Artikel bearbeiten</a></li>
                        </ul>
                    </aside>
                    <div class="content">
                        <div class="mainbox">
                            <div id="option1" class="group">
                                    <section class="lagerplatz-anlegen-form">
                                        <h3>Lagerplatz anlegen</h3>
                                        <form action="includes/lagerplatzanlegen.inc.php" method="post">
                                            <input type="text" name="Name" placeholder="Name...">
                                            <input type="text" name="Kategorie" placeholder="Kategorie...">
                                            <input type="text" name="Beschreibung" placeholder="Beschreibung...">
                                            <input type="text" name="Laenge" placeholder="Länge...">
                                            <input type="text" name="Hoehe" placeholder="Höhe...">
                                            <input type="text" name="Breite" placeholder="Breite...">
                                            <input type="text" name="Bild" placeholder="Bild(optional)...">
                                            <button type="submit"name="submit">Lagerplatz anlegen</button>
                                        </form>
                                        <?php
                                        if(isset($_GET["error"])){
                                            if($_GET["error"]=="emptyinput"){
                                                echo"<p>Sie haben ein Feld ausgelassen.</p>";
                                            }
                                            else if($_GET["error"]=="stmtfailed"){
                                                echo"<p>Da ist etwas schief gelaufen.</p>";
                                            }
                                            else if($_GET["error"]=="none"){
                                                echo"<p>Artikel wurde angelegt.</p>";
                                            }
                                        }
                                        ?>
                                    </section> 
                                </div>
                        </div>

                        <div class="mainbox">
                            <div class="explorer">
                                <form action="includes/lagerplaetzanzeigen.inc.php" method="post">
                                    <button type="submit"name="show">Lagerplätze anzeigen</button> 
                                </form> 
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include_once 'footer.php';?>