<?php include_once 'header.php';?>

            <div class="main">
                <img class="mainpic" src="images/profile.jpg" alt="bildfürblinde">
                
                <div class="mainbox">
                    <h3>Willkommen beim CWWS</h3> 
                    <p>Dies ist ein chaotisches Warenwirtschaftssystem.</p>
                </div>
            </div>

<?php include_once 'footer.php';?>